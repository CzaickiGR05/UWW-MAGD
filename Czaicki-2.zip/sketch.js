let x = 20;
let angle = 0;
const speed = 20;
const size = 50;
const rotationAmount = 0.225;
let mousePressCount = 0;
let counter = 0;
let loopCounter = 0;


function setup() {
  createCanvas(400, 400);
  textSize(12.5)
}

function draw() {
  for (let i = 0; i < 20 && loopCounter < 20; i++) {
    background(50);
    fill(255, 0, 0);
    push();
    rotate(angle);
    rect(x, height / 2 - size / 2, size, size);
    pop();
    textAlign(CENTER, CENTER);
    text('Clicks: ' + counter, width / 2, height / 2)
  }
}

function mousePressed() {
  x = (x + speed) % width;
  mousePressCount++;
  counter++;
  if (mousePressCount > 1000) {
    mousePresscount = 0;
    x = 20;
    angle = 0;
  }
}

function keyPressed() {
  angle += rotationAmount;
}