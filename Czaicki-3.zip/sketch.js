let TVpower = 0;
let TVdisplay = "Press 'o' to create smiley face!";

function setup() {
  createCanvas(400, 400);
  colorMode(RGB);
  ellipseMode(CENTER);
}

function draw() {
  background(138, 79, 43, 54);
  fill(TVpower);
  square(20, 20, 275);
  fill(100);
  ellipse(350, 50, 50);
  fill('red');
  square(325, 100, 50);
  text(TVdisplay, 75, 150, 200);
}

function mousePressed() {
  if (dist(mouseX, mouseY, 350, 50) < 75) {
    TVpower = 255;
  }
  if (dist(mouseX, mouseY, 325, 100) < 75) {
    TVpower = 100;
  }
}

function keyPressed() {
  if (key === 'o') {
    TVdisplay = ":)";
  } else {
    TVdisplay = "WRONG!";
  }
}