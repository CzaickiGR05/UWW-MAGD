let VenomSnake;
let Invisible;

function setup() {
  createCanvas(400, 400);
}

function preload() {
  // Note: Used image addresses instead of the files themselves
  VenomSnake = loadImage('https://static.wikia.nocookie.net/villains/images/0/0e/Venom-Snake-Render.png/revision/latest?cb=20210219183219');
  Invisible = loadImage('https://m.media-amazon.com/images/I/81XUFhB+1GL._UF1000,1000_QL80_.jpg')
}

function draw() {
  background(220);
  image(Invisible, 0, 0, 400, 400);
  image(VenomSnake, mouseX - 20, mouseY);
  textSize(20);
  fill('white');
  textFont('Times New Roman', 20, 40);
  text('That is NOT Solid Snake!', 105, 350);
}